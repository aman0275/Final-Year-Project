
python ./resources/magic_init/magic_init_mod.py ./train_alexnet/train_val_mi.prototxt ./train_alexnet/mi.caffemodel -nit 10 -t kmeans --gpu ${1}
