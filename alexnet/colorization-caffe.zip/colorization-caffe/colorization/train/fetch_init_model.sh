wget eecs.berkeley.edu/~rich.zhang/projects/2016_colorization/files/train/init_v2.caffemodel -O ./models/init_v2.caffemodel
