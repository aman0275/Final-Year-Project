
./caffe-colorization/build/tools/caffe train -solver ./train/solver.prototxt -snapshot $2 -gpu $1
